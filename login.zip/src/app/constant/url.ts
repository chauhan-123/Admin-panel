export const ADMIN_URL = {
    login:"url/admins/login",
    forgot:"admins/forgot-password",
    reset:"admins/reset-password",
    logout:"admins/logout",
    validateToken:"admins/verify-token",

}